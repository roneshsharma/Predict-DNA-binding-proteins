
For prediction:

Use MATLAB software to run the file Run_model.m

Sample query protein is provided

Reference:

Sharma, R., Kumar, S., Tsunoda, T., Kumarevel, T., and Sharma, A., Single-stranded and double-stranded DNA-binding protein prediction using HMM profiles, 2020.
