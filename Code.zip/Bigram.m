function [Bigram_] = Bigram(mat2,vc,LL)
for h=1:size(mat2,2)
        for h1=1:size(mat2,1)-vc
            Bi(h1,:)= mat2(h1,h) * mat2(h1+vc,:);
        end
        if LL==0
            Bigram(h,:)= roundn(sum(Bi,1),-3);
        else
            Bigram(h,:)= roundn(sum(Bi,1),-3)/size(mat2,1);
        end
       Bi=[];
end
Bigram_= Bigram(:)';

end