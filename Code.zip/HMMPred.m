function [class_1, class_2, class_3, class_4, class_5] = HMMPred(Hmm_matrix,hmmpred_model)
%Inputs
%Hmm_matrix - extracted HMM profile matrix
%hmmpred_model - Trained model for SVM, RF and KNN

%Outputs
%Predicted class for each model 

    LLhmm=1; % Parameter for normalization
    % Compute Bigram features
    test_hmmbigram(1,:) = Bigram(Hmm_matrix,1,LLhmm);

    %call models to predict
    [class_1, ~, prob_1]  = svmpredict(1,  test_hmmbigram, hmmpred_model{1},['-b 1 -q'] ); % Trained SVM model 
    [class_2, prob_2]  = predict(hmmpred_model{2}, test_hmmbigram); % Trained RF model 
    [class_3, prob_3]  = predict(hmmpred_model{3}, test_hmmbigram); % Trained KNN model 
    if class_1==1
        class_1 = 'SSB'; 
    else
        class_1 = 'DSB'; 
    end
    if class_2==1
        class_2 = 'SSB'; 
    else
        class_2 = 'DSB'; 
    end
    if class_3==1
        class_3 = 'SSB'; 
    else
        class_3 = 'DSB'; 
    end
    
    % Majority Voting
    classes = [class_1, class_2, class_3];
    if sum(classes,2) > 2 % If 2 or more models predict class 1
        class_4 = 'SSB'; 
    else
        class_4 = 'DSB';
    end

    % Maximum Probability
    Prob = [prob_1(:,1), prob_2(:,1), prob_3(:,1), prob_1(:,2), prob_2(:,2), prob_3(:,2)];

    [~,ind] = max(Prob,[],2);
    if ind>3 % If maximum probability id for class 1
        class_5 = 'SSB'; 
    else
        class_5 = 'DSB'; 
    end
end