close all
clear
clc

% This file is to run the trained model and predict the query protein seqeunces as SSB
% or DSP protein.

% Load the sequence and the extracted HMM profile of a query protein. Sample
% query protein is given for protein 3ULPB
load('Querysample.mat');

%load the Trained Model for SSB and DSB protein prediction
load('hmmpred_model.mat')

%Predict
[Query_prediction.svm,Query_prediction.rf,Query_prediction.knn,Query_prediction.Ensemble1,Query_prediction.Ensemble2] = HMMPred(Querysample.hmmprofile(:,1:20),hmmpred_model);
Query_prediction



